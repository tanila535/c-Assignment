﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    
        internal class Program
        {
            static void Main(string[] args)
            {
               
                Calculator.Addition(new List<int>() { 10, 20, 30, 40 });
            }
        }

        public class Calculator
        {
        //Using Atribute to say Use the updated Method
        [Obsolete("Use Addition(List<int> Num) Method")]    
            public static int Addition(int a, int b)
            {
                return a + b;
            }

            public static int Addition(List<int> Num)
            {
                int temp = 0;
                foreach (int i in Num)
                {
                    temp = temp + i;
                }
                Console.WriteLine(temp);
                return temp;
            Console.ReadLine();

        }

        }
    }

