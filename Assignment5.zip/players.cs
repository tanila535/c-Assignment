﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5thAssignment
{
   
public class Player
    {
        public string name;
        public int runs;

        public Player(string nm, int r)
        {
            name = nm;
            runs = r;
        }
    }
    public class Team : IEnumerable
    {
        private Player[] _people;
        public Team(Player[] pArray)
        {
            _people = new Player[pArray.Length];

            for (int i = 0; i < pArray.Length; i++)
            {
                _people[i] = pArray[i];
            }
        }

        // Implementation for the GetEnumerator method.
        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator)GetEnumerator();
        }

        public PeopleEnum GetEnumerator()
        {
            return new PeopleEnum(_people);
        }
    }

    // When you implement IEnumerable, you must also implement IEnumerator.
    public class PeopleEnum : IEnumerator
    {
        public Player[] _people;

        // Enumerators are positioned before the first element
        // until the first MoveNext() call.
        int position = -1;


        public PeopleEnum(Player[] list)
        {
            _people = list;
        }

        public bool MoveNext()
        {
            position++;
            return (position < _people.Length);
        }

        public void Reset()
        {
            position = -1;
        }

        object IEnumerator.Current
        {
            get
            {
                return Current;
            }
        }

        public Player Current
        {
            get
            {
                try
                {
                    return _people[position];
                }
                catch (IndexOutOfRangeException)
                {
                    throw new InvalidOperationException();
                }
            }
        }
    }
    class India
    {
        static void Main()
        {
            Player[] peopleArray = new Player[5]
            {
            new Player("Anila", 500),
            new Player("Jyothi", 400),
            new Player("Sravanthi", 300),
            new Player("nila", 700),
            new Player("Jyo", 600),
            };

            Team peopleList = new Team(peopleArray);
            foreach (Player p in peopleList)
                Console.WriteLine(p.name + " " + p.runs);
            Console.ReadLine();
        }
    }
}

