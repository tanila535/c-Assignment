﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5thAssignment
{
    internal class Emp
    
        {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public Emp(int eid, string ename)
        {
            this.EmpId = eid;
            this.EmpName = ename;
        }
    }
    internal class Program1
    {
        static void Main(string[] args)
        {
            //object initilizer or collection initilizer
            //ArrayList emp = new ArrayList();//non generic
            LinkedList<Emp> emp1 = new LinkedList<Emp>();
            Emp e1 = new Emp(1, "Anila");
            Emp e2 = new Emp(2, "preethi");
            Emp e3 = new Emp(3, "rashmi");
            emp1.AddLast(e1);
            emp1.AddLast(e2);
            emp1.AddLast(e3);

            string NameSearch = "Anila";
            foreach (Emp emp in emp1)
            {
                if (String.Equals(NameSearch, emp.EmpName))
                {
                    Console.WriteLine("name sarched its found");
                }
        }
        Console.ReadKey();
        }
    }
}
    

