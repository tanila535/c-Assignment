﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    internal class Program
    {
        public class Employee
        {
            private int empno;
            private string empname;
            private double salary;
            private double Hra;
            private double Ta;
            private double Da;
            private double pf;
            private double Tds;
            private double netsalary;
            private double Grosssalary;
            public Employee(int empNo, string Empname, double sal)
            {

                empno = empNo;
                empname = Empname;
                salary = sal;

                if (salary < 5000)
                {
                    Hra = salary * 10 / 100;
                    Ta = salary * 5 / 100;
                    Da = salary * 15 / 100;
                    Grosssalary = salary + Hra + Ta + Da;
                }
                else if (salary < 10000)
                {
                    Hra = salary * 15 / 100;
                    Ta = salary * 10 / 100;
                    Da = salary * 20 / 100;
                    Grosssalary = salary + Hra + Ta + Da;
                }
                else if (salary < 15000)
                {
                    Hra = salary * 20 / 100;
                    Ta = salary * 15 / 100;
                    Da = salary * 25 / 100;
                    Grosssalary = salary + Hra + Ta + Da;
                }
                else if (salary < 20000)
                {
                    Hra = salary * 25 / 100;
                    Ta = salary * 20 / 100;
                    Da = salary * 30 / 100;
                    Grosssalary = salary + Hra + Ta + Da;
                }
                else if (salary >= 20000)
                {
                    Hra = salary * 30 / 100;
                    Ta = salary * 25 / 100;
                    Da = salary * 35 / 100;
                    Grosssalary = salary + Hra + Ta + Da;
                }
            }
            public void CaluculateSalary()
            {
                pf = Grosssalary * 10 / 100;
                Tds = Grosssalary * 10 / 100;
                netsalary = Grosssalary - (pf - Tds);


            }
            public static void Main(string[] args)
            {
                Employee emp = new Employee(10, "Anila", 25000);
                Console.WriteLine("this is executing");
                emp.CaluculateSalary();
                Console.WriteLine(emp.Grosssalary);
                Console.WriteLine(emp.netsalary);
                Console.ReadLine();

            }
        }
    }
}

