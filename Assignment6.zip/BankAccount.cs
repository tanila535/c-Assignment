﻿using System;

namespace _6Assignment
{
     class Bank
    {
        public delegate void delegatemethod (int x);
        public class Account
        {
            public int AccountNumber { get; set; }
            public int CustomerName { get; set; }
            public int Balance = 1000;
            public event delegatemethod UnderBalance;
            public event delegatemethod ZeroBalance;
            public void Insufficient(int x)
            {
                UnderBalance(x);
            }
            public void DepositMoney(int y)
            {
                ZeroBalance(y);
            }
            public void withDraw(int x)
            {
                if(x<Balance &&Balance!=0)
                {
                    Console.WriteLine("Transaction Successful");
                    Console.WriteLine("Remaining balance is" + (Balance - x));

                }
               else if(x> Balance && Balance != 0)
                {
                    Console.WriteLine("Insufficient Amount");
                    Console.WriteLine("your current balance is" +(  Balance - x));


                }
                else
                {
                    Console.WriteLine("Zero balance:"+Balance);

                }

            }
            public void Deposit(int x)

            {
                Console.WriteLine("Balance after deposit:" + (Balance + x));

            }


        }
        static void Main(string[] args)
        {
            Account obj = new Account();
            Console.WriteLine("Actoin to be withdraw amount or deposit:w or d");
            string wd=Console.ReadLine();
            if(wd=="w")
            {
                Console.WriteLine("enter balance to be withdraw");
                int wdbalance=Convert.ToInt32(Console.ReadLine());
                obj.UnderBalance += new delegatemethod(obj.withDraw);
                obj.Insufficient(wdbalance);
            }
            else
            {
                Console.WriteLine("enter Amount to be deposit:");
                int dpbalance = Convert.ToInt32(Console.ReadLine());
                obj.ZeroBalance += new delegatemethod(obj.Deposit);
                obj.DepositMoney(dpbalance);

            }
            Console.ReadKey();
        }
    }
}
